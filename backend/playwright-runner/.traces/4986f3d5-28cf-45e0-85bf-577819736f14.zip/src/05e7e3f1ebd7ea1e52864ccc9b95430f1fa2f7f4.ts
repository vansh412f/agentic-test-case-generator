import { test, expect } from "../../agt-capture.ts";

test('example.com title', async ({ page }) => {
  await page.goto('https://example.com');
  await expect(page).toHaveTitle(/Example/);
});
